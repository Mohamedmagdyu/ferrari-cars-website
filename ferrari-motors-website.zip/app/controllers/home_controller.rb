class HomeController < ApplicationController
  include HomeDemoConcern

  def index
  end
end
