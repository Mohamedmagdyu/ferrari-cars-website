import consumer from './consumer'

export default consumer
