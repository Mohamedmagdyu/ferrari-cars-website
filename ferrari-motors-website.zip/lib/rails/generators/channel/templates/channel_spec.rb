require 'rails_helper'

RSpec.describe <%= channel_name %>, type: :channel do
end
