require 'rails_helper'

RSpec.describe FerrariCar, type: :model do
  # Example: Basic factory test
  # it 'can be created with factory' do
  #   record = create(:ferrari_car)
  #   expect(record).to be_persisted
  # end
end
